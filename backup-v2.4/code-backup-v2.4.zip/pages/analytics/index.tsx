import PrincipalLayout from "@components/layouts/PrincipalLayout"
import PageTemplate from "@components/template/PageTemplate"

export default function Analytics() {
  return (
    <>
      <PageTemplate title={"Analytics"} />
    </>
  )
}

Analytics.Layout = PrincipalLayout
